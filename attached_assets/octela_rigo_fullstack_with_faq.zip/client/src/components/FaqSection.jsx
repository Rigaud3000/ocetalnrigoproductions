import React from 'react';

function FaqSection({ title, faqs }) {
  return (
    <section className="bg-gray-900 text-white p-6 rounded-lg my-8">
      <h2 className="text-2xl font-bold mb-4">{title}</h2>
      <div className="space-y-4">
        {faqs.map((faq, index) => (
          <div key={index} className="border-l-4 border-red-500 pl-4">
            <h3 className="text-lg font-semibold">🧠 {faq.question}</h3>
            <p className="text-gray-300">{faq.answer}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default FaqSection;
