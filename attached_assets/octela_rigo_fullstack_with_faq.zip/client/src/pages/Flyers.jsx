import React from 'react';
import FaqSection from '../components/FaqSection';

const flyerFaqs = [
  {
    question: "Can I request flyers in different languages?",
    answer: "Yes! We design in English, Spanish, Haitian Creole, French, and more.",
  },
  {
    question: "What’s your turnaround time?",
    answer: "Most flyers are completed within 24–48 hours after concept approval.",
  },
  {
    question: "Do you offer printing too?",
    answer: "Yes — we can deliver digital designs or handle print & shipping as needed.",
  }
];

function Flyers() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-4">Business Flyer Design</h1>
      <p className="mb-6">We create custom-designed business flyers to boost your brand.</p>
      <FaqSection title="Frequently Asked Questions" faqs={flyerFaqs} />
    </div>
  );
}

export default Flyers;
