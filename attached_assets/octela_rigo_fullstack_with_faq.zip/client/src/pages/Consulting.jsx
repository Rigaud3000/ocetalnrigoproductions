import React from 'react';
import FaqSection from '../components/FaqSection';

const ConsultingFaqs = [{"question": "What kind of businesses do you consult for?", "answer": "We work with startups, service providers, and growing businesses in multiple industries."}, {"question": "What’s included in a consulting session?", "answer": "Each session includes business analysis, strategy mapping, and actionable recommendations."}, {"question": "Do you offer long-term consulting partnerships?", "answer": "Yes — we offer retainers for clients who want monthly strategy and support."}];

function Consulting() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-4">Strategic Business Consulting</h1>
      <p className="mb-6">Business strategy and consulting to elevate your growth.</p>
      <FaqSection title="Frequently Asked Questions" faqs=ConsultingFaqs />
    </div>
  );
}

export default Consulting;
