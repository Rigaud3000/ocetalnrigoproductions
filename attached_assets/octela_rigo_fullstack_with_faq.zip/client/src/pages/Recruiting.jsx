import React from 'react';
import FaqSection from '../components/FaqSection';

const RecruitingFaqs = [{"question": "How fast can I hire an agent?", "answer": "You can have qualified candidates within 48–72 hours after your request."}, {"question": "Do you vet the candidates you send?", "answer": "Yes. All agents are pre-screened for professionalism, communication skills, and experience."}, {"question": "Can I hire for short-term contracts?", "answer": "Absolutely. We provide short- and long-term placement options."}];

function Recruiting() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-4">Agent Recruiting Services</h1>
      <p className="mb-6">We help you find the best Sales and CSR agents.</p>
      <FaqSection title="Frequently Asked Questions" faqs=RecruitingFaqs />
    </div>
  );
}

export default Recruiting;
