import React from 'react';
import FaqSection from '../components/FaqSection';

const WebsitesFaqs = [{"question": "How long does it take to build my website?", "answer": "Most websites are completed within 7–14 business days, depending on complexity and features."}, {"question": "Can I request updates after the site goes live?", "answer": "Absolutely. We offer post-launch support and maintenance plans."}, {"question": "Will my site work on phones and tablets?", "answer": "Yes, every site we build is fully responsive for mobile, tablet, and desktop."}];

function Websites() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-4">Website Development Services</h1>
      <p className="mb-6">Professional websites that convert visitors into clients.</p>
      <FaqSection title="Frequently Asked Questions" faqs=WebsitesFaqs />
    </div>
  );
}

export default Websites;
