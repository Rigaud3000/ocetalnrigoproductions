import React from 'react';
import FaqSection from '../components/FaqSection';

const GrantsFaqs = [{"question": "Do you find grants for me or just file them?", "answer": "We can do both — we research available grants and handle your submission."}, {"question": "What if I don’t qualify for a grant?", "answer": "We’ll guide you to other opportunities and help prepare you for future applications."}, {"question": "How long does filing take?", "answer": "Most grant applications are completed in 3–5 business days once all info is submitted."}];

function Grants() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-4">Grant Application Filing</h1>
      <p className="mb-6">Assistance with grant filing and eligibility support.</p>
      <FaqSection title="Frequently Asked Questions" faqs=GrantsFaqs />
    </div>
  );
}

export default Grants;
