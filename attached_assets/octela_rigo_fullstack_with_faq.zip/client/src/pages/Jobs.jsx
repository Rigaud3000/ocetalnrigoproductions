import React from 'react';
import FaqSection from '../components/FaqSection';

const JobsFaqs = [{"question": "Can you help me write or update my resume?", "answer": "Yes! We professionally format and tailor your resume for specific industries or roles."}, {"question": "Will you apply to jobs for me?", "answer": "We offer guided support and can submit applications on your behalf when needed."}, {"question": "How quickly can I get started?", "answer": "Same-day support is available — once we receive your details, we get to work."}];

function Jobs() {
  return (
    <div className="p-8 text-white">
      <h1 className="text-3xl font-bold mb-4">Job Application Help</h1>
      <p className="mb-6">Get help with job applications and resume support.</p>
      <FaqSection title="Frequently Asked Questions" faqs=JobsFaqs />
    </div>
  );
}

export default Jobs;
